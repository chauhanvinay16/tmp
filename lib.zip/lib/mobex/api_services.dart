import 'dart:convert';
import 'package:http/http.dart' as http;

class Apiservices{

  Future<dynamic>getdata()async{
    try{
      var response=await http.get(Uri.parse('https://jsonplaceholder.typicode.com/posts'));
      if(response.statusCode==200){
       return jsonDecode(response.body);
      }
    }catch(error){
      print("Error==>${error.toString()}");
    }
  }
}