import 'package:flutter/material.dart';

class Stepscreen extends StatefulWidget {
  const Stepscreen({super.key});

  @override
  State<Stepscreen> createState() => _StepscreenState();
}

class _StepscreenState extends State<Stepscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('sceeen 2'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Text('this is screeen 1'),
          ],
        ),
      ),
    );
  }
}
